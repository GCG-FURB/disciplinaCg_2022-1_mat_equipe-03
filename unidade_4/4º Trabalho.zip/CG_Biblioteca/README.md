# Diagrama de Classes

![Diagrama de Classes](./svg/plantUML/CG_Biblioteca_Completo.svg "Diagrama de Classes")  
