# Diagrama de Classes

![Diagrama de Classes](./svg/plantuml/CG_N2_Completo.svg "Diagrama de Classes")  
