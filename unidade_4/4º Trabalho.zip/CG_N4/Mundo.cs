﻿/**
  Autor: Dalton Solano dos Reis
**/

//#define CG_Privado // código do professor.
// #define CG_Gizmo  // debugar gráfico.
#define CG_Debug // debugar texto.
#define CG_OpenGL // render OpenGL.
//#define CG_DirectX // render DirectX.

using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Collections.Generic;
using OpenTK.Input;
using CG_Biblioteca;

namespace gcgcg
{
  class Mundo : GameWindow
  {
    private static Mundo instanciaMundo = null;

    private Mundo(int width, int height) : base(width, height) { }

    public static Mundo GetInstance(int width, int height)
    {
      if (instanciaMundo == null)
        instanciaMundo = new Mundo(width, height);
      return instanciaMundo;
    }

    // private CameraOrtho camera = new CameraOrtho();
    private CameraPerspective cameraPerspective = new CameraPerspective();
    protected List<Objeto> objetosLista = new List<Objeto>();//mostra lista de objeto geometria

    private Poligono areaDeJogo;
    private Poligono plataforma;
    private Ponto4D pontoPlatEsq;                     

    private Poligono linhaVermelha;
    Ponto4D vermP1Esq = new Ponto4D(10, 0, 1);
    Ponto4D vermP1Dir = new Ponto4D(30, 0, 1);
    Ponto4D vermP2Esq = new Ponto4D(70, 0, 1);
    Ponto4D vermP2Dir = new Ponto4D(90, 0, 1);
    private Poligono linhaVermelha2;
    private Ponto4D pontoAcimaEsquerda;
    private Ponto4D pontoAcimaDireita;        
    private Ponto4D pontoAbaixoEsquerda;        
    private Ponto4D pontoAbaixoDireita;

    private int pontuacao = 0; 

    bool pause = true;

    Ponto4D pontoVel = new Ponto4D(0.2, 0, 0.5);
    
        
    private Ponto4D pontoPlatDir;

    private Poligono bola;


    private char objetoId = '@';

#if CG_Privado
    private Privado_SegReta obj_SegReta;
    private Privado_Circulo obj_Circulo;
#endif

    protected override void OnLoad(EventArgs e)
    {
      base.OnLoad(e);
      // camera.xmin = 0; camera.xmax = 600; camera.ymin = 0; camera.ymax = 600;
	  GL.ClearColor(0.5f, 0.5f, 0.5f, 1.0f);
      GL.Enable(EnableCap.DepthTest);
      GL.Enable(EnableCap.CullFace);

      cameraPerspective.Fovy = (float)Math.PI / 4;
      cameraPerspective.Near = 1.0f;
      cameraPerspective.Far = 5000.0f;
      cameraPerspective.Eye = new Vector3(50, 150, 51);
      cameraPerspective.At = new Vector3(50, 0, 50);

      Console.WriteLine(" --- Ajuda / Teclas: ");
      Console.WriteLine(" [  H     ] mostra teclas usadas. ");
      
    
     this.linhaVermelha = new Poligono(objetoId, null);
     this.linhaVermelha.PontosAdicionar(vermP1Esq);
     this.linhaVermelha.PontosAdicionar(vermP1Dir);
     this.linhaVermelha.ObjetoCor.CorR = (byte) 255;
     this.linhaVermelha.ObjetoCor.CorG = (byte) 0;
     this.linhaVermelha.ObjetoCor.CorB = (byte) 0;
     objetosLista.Add(this.linhaVermelha);


     this.linhaVermelha2 = new Poligono(objetoId, null);
     this.linhaVermelha2.PontosAdicionar(vermP2Esq);
     this.linhaVermelha2.PontosAdicionar(vermP2Dir);
     this.linhaVermelha2.ObjetoCor.CorR = (byte) 255;
     this.linhaVermelha2.ObjetoCor.CorG = (byte) 0;
     this.linhaVermelha2.ObjetoCor.CorB = (byte) 0;
     objetosLista.Add(this.linhaVermelha2);


     
     this.bola = new Poligono(objetoId, null);
     pontoAcimaEsquerda = new Ponto4D(49, 0, 8);
     pontoAcimaDireita = new Ponto4D(51, 0, 8);    
     pontoAbaixoDireita = new Ponto4D(51, 0, 5);
     pontoAbaixoEsquerda = new Ponto4D(49, 0, 5);

     this.bola.PontosAdicionar(pontoAcimaEsquerda);
     this.bola.PontosAdicionar(pontoAcimaDireita);
     this.bola.PontosAdicionar(pontoAbaixoDireita);
     this.bola.PontosAdicionar(pontoAbaixoEsquerda);
     objetosLista.Add(this.bola);

     
      this.areaDeJogo = new Poligono(objetoId, null);
      this.areaDeJogo.PontosAdicionar(new Ponto4D(0, 0, 0));
      this.areaDeJogo.PontosAdicionar(new Ponto4D(0, 0, 100));
      this.areaDeJogo.PontosAdicionar(new Ponto4D(100, 0, 100));
      this.areaDeJogo.PontosAdicionar(new Ponto4D(100, 0, 0));
      objetosLista.Add(this.areaDeJogo);


      pontoPlatDir = new Ponto4D(60, 0, 90);
      pontoPlatEsq = new Ponto4D(40, 0, 90);
      this.plataforma = new Poligono(objetoId, null);
      this.plataforma.PontosAdicionar(pontoPlatDir);
      this.plataforma.PontosAdicionar(pontoPlatEsq);
      objetosLista.Add(this.plataforma);
    }



    private void reiniciarJogo() {
      pause = true;
      pontoAcimaEsquerda.X = 49;
      pontoAcimaEsquerda.Z  = 8;
      pontoAcimaDireita.X = 51;    
      pontoAcimaDireita.Z = 8;    
      pontoAbaixoDireita.X = 51;
      pontoAbaixoDireita.Z = 5;
      pontoAbaixoEsquerda.X = 49;
      pontoAbaixoEsquerda.Z = 5;
      this.pontoPlatEsq.X = 40;
      this.pontoPlatDir.X = 60;
      this.pontoVel.X = 0.2;
      this.pontoVel.Z = 0.2;
      this.pontuacao = 0;
    }




    protected void mover4Pontos(Ponto4D ponto) {
      pontoAcimaEsquerda.X += ponto.X;      
      pontoAbaixoDireita.X += ponto.X;
      pontoAcimaDireita.X += ponto.X;
      pontoAbaixoEsquerda.X += ponto.X;
      pontoAcimaEsquerda.Z += ponto.Z;      
      pontoAbaixoDireita.Z += ponto.Z;
      pontoAcimaDireita.Z += ponto.Z;
      pontoAbaixoEsquerda.Z += ponto.Z;
    }

    private double randomAngle() {
      if(pontoVel.X > 0.5) {
        pontoVel.X = 0.2;
        return 0;
      }
      if(pontoVel.X < -0.5) {
        pontoVel.X = -0.2;
        return 0;
      }
      Random rnd = new Random();
      double angulo  = rnd.Next();
      if (angulo < 0) {
        angulo = -0.1;
      } else {
        angulo = 0.1;
      }
      if (angulo + pontoVel.X == 0) {
         if(pontoVel.X > 0) {
        pontoVel.X = 0.2;
        return 0;
      }else {
        pontoVel.X = -0.2;
        return 0;
      } 
      }
      return angulo;
    }

    protected void moverBola() {

      if(pontoAcimaEsquerda.X < 1) { // Mudar valores
        pontoVel.X = -pontoVel.X + randomAngle();
      }

      if(pontoAcimaDireita.X > 99) { // Mudar valores
        pontoVel.X = -pontoVel.X - randomAngle();
      }

      if(pontoAbaixoEsquerda.Z > 97) {
        pontuacao -= 2;
        Console.WriteLine(pontuacao);
        if(this.pontuacao < -5) {
          Console.WriteLine("Perdeu");
          reiniciarJogo();
        }
        pontoVel.Z = -pontoVel.Z;
      }

      if(pontoAcimaEsquerda.Z < 3) {
       if((pontoAbaixoEsquerda.X >= vermP1Esq.X && pontoAbaixoEsquerda.X <= vermP1Dir.X) || (pontoAbaixoDireita.X >= vermP2Esq.X && pontoAbaixoDireita.X <= vermP2Dir.X)) {
         pontuacao++;
         Console.WriteLine(pontuacao);
          if(this.pontuacao > 5) {
          Console.WriteLine("Ganhou!");
          reiniciarJogo();
        }
          }

        pontoVel.Z = -pontoVel.Z;
      }
       if(pontoAbaixoEsquerda.Z >= pontoPlatDir.Z -3) {

         if((pontoAbaixoEsquerda.X >= pontoPlatEsq.X && pontoAbaixoEsquerda.X <= pontoPlatDir.X) || (pontoAbaixoDireita.X >= pontoPlatEsq.X && pontoAbaixoDireita.X <= pontoPlatDir.X)) {
            if(pontoVel.Z > 0) {
             pontoVel.Z = -pontoVel.Z;

            }
         }      
      } 
      mover4Pontos(pontoVel);
    }


    protected override void OnUpdateFrame(FrameEventArgs e)
    {
      base.OnUpdateFrame(e);
      if(pause == false) {
        moverBola();       
      }
    }

    protected override void OnResize(EventArgs e)
    {
      base.OnResize(e);
      cameraPerspective.Aspect = Width / (float)Height;
      GL.Viewport(ClientRectangle.X, ClientRectangle.Y, ClientRectangle.Width, ClientRectangle.Height);
      Matrix4 projection = Matrix4.CreatePerspectiveFieldOfView(cameraPerspective.Fovy, cameraPerspective.Aspect, cameraPerspective.Near, cameraPerspective.Far);
      GL.MatrixMode(MatrixMode.Projection);
      GL.LoadMatrix(ref projection);
    }

    protected override void OnRenderFrame(FrameEventArgs e)
    {
      base.OnRenderFrame(e);
#if CG_OpenGL
 

GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

      Matrix4 modelview = Matrix4.LookAt(cameraPerspective.Eye,cameraPerspective.At,cameraPerspective.Up);
      GL.MatrixMode(MatrixMode.Modelview);
      GL.LoadMatrix(ref modelview);

#endif
#if CG_Gizmo      
      Sru3D();
#endif
      for (var i = 0; i < objetosLista.Count; i++)
        objetosLista[i].Desenhar();
#if CG_Gizmo
      if (bBoxDesenhar && (objetoSelecionado != null))
        objetoSelecionado.BBox.Desenhar();
#endif

      this.SwapBuffers();
    }

    protected override void OnKeyDown(OpenTK.Input.KeyboardKeyEventArgs e)
    {
      if (e.Key == Key.H)
        Utilitario.AjudaTeclado();
      else if (e.Key == Key.Escape)
        Exit();
      else if (e.Key == Key.E)
      {
        Console.WriteLine("--- Objetos / Pontos: ");
        for (var i = 0; i < objetosLista.Count; i++)
        {
          Console.WriteLine(objetosLista[i]);
        }
      } else if(e.Key == Key.Space) {
        pause = !pause;
      }
       else if(e.Key == Key.R) {
        reiniciarJogo();
      }
     


       else if(pause == false) {
          if (e.Key == Key.Left) {
          Ponto4D esquerda = new Ponto4D(2, 0, 0);
        
          if(pontoPlatEsq.X >esquerda.X){
          move(-7.0);
        }
        }
        if (e.Key == Key.Right) {
          Ponto4D direita = new Ponto4D(98, 0, 0);
          if(pontoPlatDir.X <direita.X){
          move(7.0);
          }
        }
        }
        
      else
        Console.WriteLine(" __ Tecla não implementada.");
    }

    

    //TODO: não está considerando o NDC

    private void move(double val){
      pontoPlatEsq.X = pontoPlatEsq.X + val;
      pontoPlatDir.X = pontoPlatDir.X + val;
    }
       
#if CG_Gizmo
    private void Sru3D()
    {
#if CG_OpenGL
      GL.LineWidth(1);
      GL.Begin(PrimitiveType.Lines);
      // GL.Color3(1.0f,0.0f,0.0f);
      GL.Color3(Convert.ToByte(255), Convert.ToByte(0), Convert.ToByte(0));
      GL.Vertex3(0, 0, 0); GL.Vertex3(100, 0, 0);
      // GL.Color3(0.0f,1.0f,0.0f);
      GL.Color3(Convert.ToByte(0), Convert.ToByte(255), Convert.ToByte(0));
      GL.Vertex3(0, 0, 0); GL.Vertex3(0, 100, 0);
      // GL.Color3(0.0f,0.0f,1.0f);
      GL.Color3(Convert.ToByte(0), Convert.ToByte(0), Convert.ToByte(255));
      GL.Vertex3(0, 0, 0); GL.Vertex3(0, 0, 100);
      GL.End();
#endif
    }
#endif    
  }
  class Program
  {
    static void Main(string[] args)
    {
      ToolkitOptions.Default.EnableHighResolution = false;
      Mundo window = Mundo.GetInstance(600, 600);
      window.Title = "CG_N2";
      window.Run(1.0 / 60.0);

    }
  }
}
